version https://git-lfs.github.com/spec/v1
oid sha256:6873971f153bad0b4bb921ba0ed78b71cca83ef3ac57ec841912fdf92608beb5
size 7024
