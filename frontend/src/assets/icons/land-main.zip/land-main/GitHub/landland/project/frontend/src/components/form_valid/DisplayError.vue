version https://git-lfs.github.com/spec/v1
oid sha256:8cb26d25eb36d9283187ee82af1ad48ab5fad12c3cdd73f4710ce992206bcfc7
size 462
